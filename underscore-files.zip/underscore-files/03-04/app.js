var fireIntheHole = function() {
    console.log('Boommmmm...');
    console.log('Boommmmm...');
    console.log('Boommmmm...');
    console.log('Boommmmm...');
    console.log('Boommmmm...');
    console.log('Boommmmm...');
    console.log('Boommmmm...');
    console.log('Boommmmm...');
    console.log('Boommmmm...');
    console.log('Boommmmm...');
    console.log('Boommmmm...');
};

var run = function() {
    console.log('捂上耳朵，狂奔！');
}

_.defer(fireIntheHole);
run();