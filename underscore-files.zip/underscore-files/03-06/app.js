var fireIntheHole = function() {
    console.log('Boommmm...');
};

var fire = _.once(fireIntheHole);